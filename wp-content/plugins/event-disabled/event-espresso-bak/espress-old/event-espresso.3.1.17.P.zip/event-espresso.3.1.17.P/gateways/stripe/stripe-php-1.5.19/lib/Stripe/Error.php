<?php

class Stripe_Error extends Exception
{
}
