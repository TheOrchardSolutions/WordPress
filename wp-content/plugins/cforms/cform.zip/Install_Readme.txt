
v10.4 Patch 1
-------------


Simply copy all files to your cforms folder on your server.



Patch 1
~~~~~~~
* addresses EMAIL / MIME boundary issue
* Ajax / tracking issue