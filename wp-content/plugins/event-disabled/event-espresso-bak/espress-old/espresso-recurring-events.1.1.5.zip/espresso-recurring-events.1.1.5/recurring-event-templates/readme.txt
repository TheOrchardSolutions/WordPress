These files should be added to your wp-content/uploads/espresso/templates/ directory. Be sure to backup any files before overwriting.

The following piece of code needs to be added to your themes CSS file.

.subpage_excerpt .date_picker{
	display: none;
}