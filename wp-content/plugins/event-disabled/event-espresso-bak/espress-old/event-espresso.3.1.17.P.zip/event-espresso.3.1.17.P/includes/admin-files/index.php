<?php 
/* Silence is golden */
?>