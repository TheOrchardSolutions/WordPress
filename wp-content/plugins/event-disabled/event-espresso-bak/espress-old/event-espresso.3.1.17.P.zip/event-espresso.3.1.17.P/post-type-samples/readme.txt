For more information about these files, please refer to http://eventespresso.com/forums/?p=922

For template variables and Shortcodes please visit http://eventespresso.com/forums/?p=761