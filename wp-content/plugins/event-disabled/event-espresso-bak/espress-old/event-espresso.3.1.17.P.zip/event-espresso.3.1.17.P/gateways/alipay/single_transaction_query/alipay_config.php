<?php

$partner = "";//fill with the partnerID which we already offered you (required fields)
$security_code = "";//fill with the security key which we already offered you (required fields)
$_input_charset = "utf-8"; 
$sign_type = "MD5"; 
?>