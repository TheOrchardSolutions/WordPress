<?php

class Nothing_Action extends Red_Action
{
	function can_perform_action () { return false; }
}
