=== Nextend ===
Contributors: nextendweb 
Tags: nextend library
Donate link: https://www.facebook.com/nextendweb
Requires at least: 3.0
Tested up to: 3.7.1
Stable tag: 1.3.4
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Nextend Library for Accordion Menu and Smart Slider 2.

== Description ==

Core library for Nextendweb plugins. It provides the Nextend framework, parameters, settings.

== Installation ==

1.  Extract the zip file and just drop the contents in the wp-content/plugins/ directory of your WordPress installation and then activate the Plugin from Plugins page.


== Changelog ==

= 1.3.4 =
* Some fixes

= 1.3.3 =
* Some fixes

= 1.3.2 =
* Some fixes

= 1.3.1 =
* Some fixes

= 1.3.0 =
* Some fixes

= 1.1.9 =
* Some fixes

= 1.1.7 =
* Some fixes

= 1.1.6 =
* Cache time now can be 'static'

= 1.1.5 =
* Some fixes

= 1.1.4 =
* Fix for some bugs

= 1.1.3 =
* Fix for a bug when stylesheet isn't displayed properly

= 1.1.1 =
* New features for Smart Slider 2 and Accordion Menu

= 1.1.0 =
* Feature: Smart Slider 2 compatibility

= 1.0.8 =
* Fix: https support added

= 1.0.7 =
* Fix: Admin theme conflict

= 1.0.6 =
* Feature: Nextend global settings page added
* Fix: Headway fix

= 1.0.5 =
* Fix: CSS is not loaded on backend

= 1.0.4 =
* Accordion menu 2D and 3D transitions

= 1.0.1 =
* Update fix

= 1.0.0 =
* Initial release